# finanomaly — движок выявления финансовых аномалий

Вычислительный движок, который тянет данные по **API биржи (Binance)** или из
**CSV-выгрузки** и находит во временном ряде подозрительные точки: резкие
всплески объёма/цены, нетипичные провалы, устойчивые сдвиги уровня. Каждая
аномалия получает итоговую оценку 0..1, разложение по вкладу детекторов и
объяснение на естественном языке (через **Claude API** при наличии ключа, иначе
детерминированный rule-based фолбэк).

Ядро написано на чистом Python (включая собственный FFT), поэтому работает без
тяжёлых зависимостей; `scikit-learn` и `anthropic` подключаются опционально.

## Вычислительный движок

Конвейер `AnomalyEngine`:

1. **Предобработка** — опциональное лог-преобразование для рядов с
   мультипликативным шумом (включается автоматически по коэффициенту вариации).
2. **Оценка периода** — доминирующая сезонность через автокорреляцию.
3. **Декомпозиция** — снятие тренда и сезонности (аддитивная модель), детекторы
   работают на стационарном остатке.
4. **Ансамбль детекторов** — каждый выдаёт непрерывную оценку 0..1 по всем точкам:
   | детектор | что ловит | метод |
   |---|---|---|
   | `robust_mad` | глобальные выбросы | медиана + MAD (устойчиво к выбросам) |
   | `spectral_residual` | резкие точечные аномалии | спектральный остаток (FFT-saliency, метод Microsoft) |
   | `ewma` | смещения уровня | контрольная карта EWMA ±kσ |
   | `cusum` | постепенный увод среднего | двусторонний CUSUM |
   | `hampel` | локальные выбросы | скользящая робастная z-оценка |
   | `isolation_forest` | контекстные аномалии | ML по многомерным признакам *(опц., sklearn)* |
5. **Слияние** — взвешенный noisy-OR `P = 1 − Π(1 − wᵢ·sᵢ)`: согласие
   независимых методов даёт уверенную оценку и режет ложные срабатывания.
6. **Решение** — порог, направление (рост/падение) и причина.

Для реального времени есть `StreamingDetector` — инкрементальная оценка каждого
нового значения за O(window) без пересчёта истории.

## Установка

```bash
cd "project 3"
python3 -m venv .venv && source .venv/bin/activate
pip install requests                       # для биржевого источника
# опционально:
pip install scikit-learn numpy anthropic   # ML-детектор и ИИ-объяснения
```

## Быстрый старт

```bash
export PYTHONPATH=src

# Реальные данные с биржи — всплески объёма BTC/USDT по часам
python -m finanomaly.cli --source binance --symbol BTCUSDT --interval 1h --metric volume

# Своя CSV-выгрузка (колонки: timestamp,value[,label])
python -m finanomaly.cli --source csv --path account.csv --json

# Управление чувствительностью
python -m finanomaly.cli --source binance --symbol ETHUSDT --threshold 0.7 --period 24
```

Включить ИИ-объяснения от Claude:

```bash
export ANTHROPIC_API_KEY=sk-ant-...        # см. .env.example
python -m finanomaly.cli --source binance
```

## Пример вывода

```
Источник: binance | точек: 300 | период≈24 | ИИ: rule-based
Детекторы: robust_mad, spectral_residual, ewma, cusum, hampel, isolation_forest
Найдено аномалий: 18 (🔴 8  🟠 5  🟡 5)  доля: 6.0%

🔴 2026-06-07 22:00        4,892.75  score=1.00  (robust_mad=0.95, spectral_residual=0.79, cusum=0.63, hampel=0.60)
     ↳ Резкий рост объёма ... уровень риска: high. Требует немедленной проверки.
```

## Программный API

```python
from finanomaly import AnomalyEngine
from finanomaly.data_sources import BinanceSource

series = BinanceSource(symbol="ETHUSDT", metric="volume").fetch()
result = AnomalyEngine(threshold=0.6).run(series)

print(result.summary())
for a in result.anomalies:
    print(a.score, a.direction, a.contributions)

# Потоковый режим
from finanomaly import StreamingDetector
det = StreamingDetector()
for point in series:
    anomaly = det.push(point)
    if anomaly:
        print("ALERT", anomaly.point.timestamp, anomaly.score)
```

## Тесты

```bash
python -m pytest -q              # если установлен pytest
python tests/test_engine.py      # без pytest
```

Покрыты: FFT (round-trip и сверка с эталоном), робастная статистика, сезонная
декомпозиция, оценка периода, слияние оценок, движок целиком (детекция
заложенных аномалий и низкий уровень ложных срабатываний), потоковый детектор.

## Структура

```
src/finanomaly/
├── engine/                 вычислительный движок
│   ├── fft.py              FFT на чистом Python (Cooley–Tukey)
│   ├── preprocessing.py    робастная статистика, декомпозиция, оценка периода
│   ├── detectors.py        6 детекторов → непрерывные оценки
│   ├── fusion.py           взвешенный noisy-OR
│   ├── core.py             AnomalyEngine — оркестратор
│   └── streaming.py        онлайн-детектор реального времени
├── data_sources/           адаптеры API → единый DataPoint (binance, csv)
├── ai_explainer.py         Claude API с rule-based фолбэком
├── pipeline.py             источник → движок → объяснения
└── cli.py                  терминальный интерфейс
```

## Замечания

- Новый источник данных (другой банк/биржа) подключается одним классом
  `DataSource` с методом `fetch()` — движок при этом не меняется.
- Реальный банковский API (открытый банкинг / Plaid и т.п.) требует авторизации
  владельца счёта и реализуется как ещё один `DataSource`.
- Инструмент аналитический: решения о блокировках/трейдах принимает человек.
```
