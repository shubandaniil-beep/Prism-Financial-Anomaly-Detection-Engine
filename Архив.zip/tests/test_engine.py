"""Тесты вычислительного движка. Запуск:
    python -m pytest -q
    python tests/test_engine.py        # без pytest
"""

import math
import random
import sys
from datetime import datetime, timedelta, timezone
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))

from finanomaly.engine import AnomalyEngine, StreamingDetector
from finanomaly.engine.fft import amplitude_phase, fft, ifft, next_pow2
from finanomaly.engine import preprocessing as pp
from finanomaly.engine.fusion import fuse_point, fuse_series
from finanomaly.models import DataPoint


# --- генератор синтетического ряда с трендом, сезонностью и аномалиями ---

def make_series(n=240, anomaly_idx=(60, 150, 200), seed=7):
    rng = random.Random(seed)
    base = datetime(2024, 1, 1, tzinfo=timezone.utc)
    points = []
    for i in range(n):
        trend = 1000 + 2.0 * i
        seasonal = 120 * math.sin(2 * math.pi * (i % 24) / 24)
        noise = rng.gauss(0, 25)
        value = trend + seasonal + noise
        if i in anomaly_idx:
            value += 900 if i % 2 == 0 else -800
        points.append(DataPoint(base + timedelta(hours=i), value, "synthetic"))
    return points


# --- FFT ---

def test_next_pow2():
    assert next_pow2(1) == 1
    assert next_pow2(5) == 8
    assert next_pow2(1024) == 1024


def test_fft_roundtrip():
    x = [complex(v, 0) for v in [1, 2, 3, 4, 5, 6, 7, 8]]
    back = ifft(fft(x))
    assert all(abs(a - b) < 1e-9 for a, b in zip(x, back))


def test_fft_matches_known_dft():
    x = [complex(v, 0) for v in [1, 0, 0, 0]]  # импульс -> плоский спектр
    spec = fft(x)
    assert all(abs(z - 1) < 1e-9 for z in spec)


def test_amplitude_phase_pads():
    amp, phase, m = amplitude_phase([1.0, 2.0, 3.0])
    assert m == 4 and len(amp) == 4 == len(phase)


# --- препроцессинг ---

def test_mad_and_median():
    xs = [1, 2, 3, 4, 5, 100]
    assert pp.median(xs) == 3.5
    assert pp.mad(xs) > 0


def test_seasonal_decompose_recovers_components():
    vals = [100 + 10 * math.sin(2 * math.pi * (i % 12) / 12) for i in range(120)]
    d = pp.seasonal_decompose(vals, period=12)
    # Во внутренней части (без краевых эффектов скользящего среднего)
    # остаток должен быть мал по сравнению с сезонной амплитудой (=10).
    interior = d["residual"][12:-12]
    assert max(abs(r) for r in interior) < 2


def test_detect_period_finds_seasonality():
    vals = [math.sin(2 * math.pi * (i % 20) / 20) for i in range(200)]
    assert pp.detect_period(vals) in (20, 40)


# --- слияние ---

def test_fuse_point_rewards_agreement():
    single = fuse_point([0.6], [1.0])
    agree = fuse_point([0.6, 0.6], [1.0, 1.0])
    assert agree > single
    assert 0.0 <= agree <= 1.0


def test_fuse_series_shape():
    fused = fuse_series([[0.1, 0.9], [0.2, 0.8]], [1.0, 1.0])
    assert len(fused) == 2 and fused[1] > fused[0]


# --- движок целиком ---

def test_engine_detects_injected_anomalies():
    series = make_series()
    result = AnomalyEngine().run(series)
    found = {a.point.timestamp for a in result.anomalies}
    expected = {series[i].timestamp for i in (60, 150, 200)}
    assert expected & found, "движок должен найти заложенные аномалии"
    assert all(0.0 <= a.score <= 1.0 for a in result.anomalies)


def test_engine_low_false_positive_on_clean_series():
    series = make_series(anomaly_idx=())  # без аномалий
    result = AnomalyEngine().run(series)
    assert result.anomaly_rate < 0.05


def test_engine_contributions_and_direction():
    series = make_series()
    result = AnomalyEngine().run(series)
    a = result.anomalies[0]
    assert a.contributions and a.direction in ("up", "down")
    assert a.method  # производное от вкладов


def test_engine_summary_shape():
    result = AnomalyEngine().run(make_series())
    s = result.summary()
    assert set(s) >= {"points", "anomalies", "anomaly_rate", "by_severity", "period", "detectors"}


def test_engine_handles_empty_and_tiny():
    assert AnomalyEngine().run([]).anomalies == []
    tiny = make_series(n=3, anomaly_idx=())
    assert AnomalyEngine().run(tiny).anomalies == []


# --- потоковый детектор ---

def test_streaming_flags_spike():
    det = StreamingDetector(warmup=10)
    base = datetime(2024, 1, 1, tzinfo=timezone.utc)
    flagged = []
    for i in range(80):
        val = 100.0 + (5 if i % 2 else 0)
        if i == 60:
            val = 900.0  # выброс
        a = det.push(DataPoint(base + timedelta(minutes=i), val, "stream"))
        if a:
            flagged.append(i)
    assert 60 in flagged


if __name__ == "__main__":
    fns = [v for k, v in sorted(globals().items()) if k.startswith("test_")]
    for fn in fns:
        fn()
        print(f"ok  {fn.__name__}")
    print(f"\nВсе {len(fns)} тестов прошли.")
