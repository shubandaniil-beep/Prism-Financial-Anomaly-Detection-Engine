"""CLI: запуск вычислительного движка детекции аномалий.

Примеры:
  python -m finanomaly.cli --source binance --symbol BTCUSDT --interval 1h --metric volume
  python -m finanomaly.cli --source csv --path account.csv --json
"""

from __future__ import annotations

import argparse
import json
import sys

from .ai_explainer import AiExplainer
from .data_sources import BinanceSource, CsvSource
from .engine.core import AnomalyEngine
from .pipeline import AnomalyPipeline

_SEV_ICON = {"high": "🔴", "medium": "🟠", "low": "🟡"}


def build_source(args: argparse.Namespace):
    if args.source == "binance":
        return BinanceSource(
            symbol=args.symbol, interval=args.interval, limit=args.limit, metric=args.metric
        )
    if args.source == "csv":
        if not args.path:
            sys.exit("Для --source csv нужен --path")
        return CsvSource(args.path)
    raise ValueError(args.source)


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Вычислительный движок выявления финансовых аномалий")
    parser.add_argument("--source", choices=["binance", "csv"], default="binance")
    parser.add_argument("--symbol", default="BTCUSDT")
    parser.add_argument("--interval", default="1h")
    parser.add_argument("--metric", choices=["close", "volume"], default="volume")
    parser.add_argument("--limit", type=int, default=500)
    parser.add_argument("--path", help="CSV-файл для --source csv")
    parser.add_argument("--threshold", type=float, default=0.5, help="порог оценки 0..1")
    parser.add_argument("--period", type=int, help="период сезонности (по умолч. авто)")
    parser.add_argument("--no-ai", action="store_true", help="отключить ИИ-объяснения")
    parser.add_argument("--json", action="store_true", help="вывод в JSON")
    args = parser.parse_args(argv)

    source = build_source(args)
    engine = AnomalyEngine(threshold=args.threshold, period=args.period)
    pipeline = AnomalyPipeline(
        source=source, engine=engine, explainer=AiExplainer(enabled=not args.no_ai)
    )

    try:
        result = pipeline.run(explain=not args.no_ai)
    except Exception as exc:
        sys.exit(f"Ошибка получения данных: {exc}")

    if args.json:
        print(json.dumps(
            {"summary": result.summary(), "anomalies": [a.to_dict() for a in result.anomalies]},
            ensure_ascii=False, indent=2,
        ))
        return 0

    s = result.summary()
    ai_mode = "Claude API" if pipeline.explainer.use_llm else "rule-based"
    print(f"\nИсточник: {source.name} | точек: {s['points']} | период≈{s['period'] or '—'} | ИИ: {ai_mode}")
    print(f"Детекторы: {', '.join(s['detectors'])}")
    print(
        f"Найдено аномалий: {s['anomalies']} "
        f"(🔴 {s['by_severity']['high']}  🟠 {s['by_severity']['medium']}  "
        f"🟡 {s['by_severity']['low']})  доля: {s['anomaly_rate']:.1%}\n"
    )
    if not result.anomalies:
        print("Аномалий не обнаружено.")
        return 0

    for a in result.anomalies:
        icon = _SEV_ICON[a.severity]
        contrib = ", ".join(f"{k}={v:.2f}" for k, v in list(a.contributions.items())[:4])
        print(f"{icon} {a.point.timestamp:%Y-%m-%d %H:%M}  {a.point.value:>14,.2f}  "
              f"score={a.score:.2f}  ({contrib})")
        if a.ai_explanation:
            print(f"     ↳ {a.ai_explanation}")
    print()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
