"""finanomaly — выявление финансовых аномалий через ИИ по API банка или биржи."""

from .engine import AnomalyEngine, EngineResult, StreamingDetector
from .models import Anomaly, DataPoint
from .pipeline import AnomalyPipeline

__version__ = "0.2.0"
__all__ = [
    "DataPoint",
    "Anomaly",
    "AnomalyEngine",
    "EngineResult",
    "StreamingDetector",
    "AnomalyPipeline",
]
