"""Источник: публичный API биржи Binance (без ключа и регистрации).

Тянет свечи (klines) и превращает их в ряд значений выбранной метрики:
цена закрытия или объём торгов. Объём особенно полезен для поиска аномалий —
резкие всплески объёма часто сопровождают манипуляции и инсайдерскую активность.

Документация: https://api.binance.com/api/v3/klines
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from ..models import DataPoint
from .base import DataSource

if TYPE_CHECKING:  # подсказки типов без обязательной зависимости
    import requests

_BASE_URL = "https://api.binance.com/api/v3/klines"

# Индексы полей в ответе klines
_OPEN_TIME, _OPEN, _HIGH, _LOW, _CLOSE, _VOLUME = 0, 1, 2, 3, 4, 5


class BinanceSource(DataSource):
    name = "binance"

    def __init__(
        self,
        symbol: str = "BTCUSDT",
        interval: str = "1h",
        limit: int = 500,
        metric: str = "close",        # "close" | "volume"
        timeout: float = 10.0,
        session: "requests.Session | None" = None,
    ) -> None:
        if metric not in ("close", "volume"):
            raise ValueError("metric должен быть 'close' или 'volume'")
        self.symbol = symbol.upper()
        self.interval = interval
        self.limit = min(max(limit, 1), 1000)
        self.metric = metric
        self.timeout = timeout
        self._session = session

    def fetch(self) -> list[DataPoint]:
        try:
            import requests
        except ModuleNotFoundError as exc:  # pragma: no cover
            raise RuntimeError(
                "Для источника binance нужен пакет requests: pip install requests"
            ) from exc

        session = self._session or requests.Session()
        params = {"symbol": self.symbol, "interval": self.interval, "limit": self.limit}
        resp = session.get(_BASE_URL, params=params, timeout=self.timeout)
        resp.raise_for_status()
        rows = resp.json()

        idx = _CLOSE if self.metric == "close" else _VOLUME
        label = f"{self.symbol} {self.metric}"
        points: list[DataPoint] = []
        for row in rows:
            points.append(
                DataPoint.from_epoch_ms(
                    ts_ms=int(row[_OPEN_TIME]),
                    value=float(row[idx]),
                    label=label,
                    symbol=self.symbol,
                    interval=self.interval,
                    metric=self.metric,
                    close=float(row[_CLOSE]),
                    volume=float(row[_VOLUME]),
                )
            )
        return points
