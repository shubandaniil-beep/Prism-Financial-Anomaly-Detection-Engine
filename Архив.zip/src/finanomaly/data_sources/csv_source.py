"""Источник: CSV-файл с колонками timestamp,value[,label].

Удобно для воспроизводимых демо и подгрузки выгрузок из банковского ЛК.
timestamp понимается как ISO-8601 или как unix-секунды/миллисекунды.
"""

from __future__ import annotations

import csv
from datetime import datetime, timezone
from pathlib import Path

from ..models import DataPoint
from .base import DataSource


def _parse_ts(raw: str) -> datetime:
    raw = raw.strip()
    if raw.isdigit():
        n = int(raw)
        if n > 10_000_000_000:  # это миллисекунды
            n //= 1000
        return datetime.fromtimestamp(n, tz=timezone.utc)
    return datetime.fromisoformat(raw)


class CsvSource(DataSource):
    name = "csv"

    def __init__(self, path: str | Path) -> None:
        self.path = Path(path)

    def fetch(self) -> list[DataPoint]:
        points: list[DataPoint] = []
        with self.path.open(newline="", encoding="utf-8") as fh:
            reader = csv.DictReader(fh)
            for row in reader:
                points.append(
                    DataPoint(
                        timestamp=_parse_ts(row["timestamp"]),
                        value=float(row["value"]),
                        label=row.get("label", self.path.stem),
                    )
                )
        points.sort(key=lambda p: p.timestamp)
        return points
