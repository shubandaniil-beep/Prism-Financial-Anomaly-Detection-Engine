"""Контракт источника данных.

Чтобы подключить новый банк/биржу — достаточно реализовать `fetch()`,
вернув список DataPoint. Детекторы и пайплайн при этом не меняются.
"""

from __future__ import annotations

from abc import ABC, abstractmethod

from ..models import DataPoint


class DataSource(ABC):
    name: str = "base"

    @abstractmethod
    def fetch(self) -> list[DataPoint]:
        """Вернуть временной ряд, отсортированный по времени (по возрастанию)."""
        raise NotImplementedError
