"""Источники данных. Все приводят данные к списку DataPoint."""

from .base import DataSource
from .binance import BinanceSource
from .csv_source import CsvSource

__all__ = ["DataSource", "BinanceSource", "CsvSource"]
