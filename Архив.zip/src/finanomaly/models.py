"""Базовые структуры данных, единые для источников и вычислительного движка."""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any


@dataclass(frozen=True)
class DataPoint:
    """Одна точка временного ряда финансовой метрики."""

    timestamp: datetime
    value: float
    label: str = ""
    meta: dict[str, Any] = field(default_factory=dict)

    @staticmethod
    def from_epoch_ms(ts_ms: int, value: float, label: str = "", **meta: Any) -> "DataPoint":
        return DataPoint(
            timestamp=datetime.fromtimestamp(ts_ms / 1000, tz=timezone.utc),
            value=float(value),
            label=label,
            meta=meta,
        )


@dataclass
class Anomaly:
    """Обнаруженная аномалия с разложением по вкладу детекторов."""

    point: DataPoint
    score: float                              # итоговая уверенность 0..1
    direction: str                            # "up" | "down"
    contributions: dict[str, float] = field(default_factory=dict)  # детектор -> вклад
    reason: str = ""
    ai_explanation: str = ""

    @property
    def severity(self) -> str:
        if self.score >= 0.85:
            return "high"
        if self.score >= 0.6:
            return "medium"
        return "low"

    @property
    def method(self) -> str:
        top = sorted(self.contributions.items(), key=lambda kv: kv[1], reverse=True)
        return "+".join(name for name, _ in top) or "engine"

    def to_dict(self) -> dict[str, Any]:
        return {
            "timestamp": self.point.timestamp.isoformat(),
            "label": self.point.label,
            "value": self.point.value,
            "score": round(self.score, 4),
            "severity": self.severity,
            "direction": self.direction,
            "contributions": {k: round(v, 4) for k, v in self.contributions.items()},
            "reason": self.reason,
            "ai_explanation": self.ai_explanation,
        }
