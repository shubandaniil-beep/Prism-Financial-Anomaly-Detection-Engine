"""Пайплайн: источник → вычислительный движок → (опц.) ИИ-объяснения."""

from __future__ import annotations

from .ai_explainer import AiExplainer
from .data_sources.base import DataSource
from .engine.core import AnomalyEngine, EngineResult


class AnomalyPipeline:
    def __init__(
        self,
        source: DataSource,
        engine: AnomalyEngine | None = None,
        explainer: AiExplainer | None = None,
    ) -> None:
        self.source = source
        self.engine = engine or AnomalyEngine()
        self.explainer = explainer or AiExplainer()

    def run(self, explain: bool = True) -> EngineResult:
        series = self.source.fetch()
        result = self.engine.run(series)
        if explain:
            self.explainer.annotate(result.anomalies)
        return result
