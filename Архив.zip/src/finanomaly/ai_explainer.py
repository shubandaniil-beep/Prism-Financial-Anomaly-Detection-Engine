"""ИИ-слой: объяснение аномалий на естественном языке.

Если задан ANTHROPIC_API_KEY и установлен пакет `anthropic`, объяснения и
оценку риска генерирует Claude. Иначе используется детерминированный
rule-based фолбэк — проект остаётся полностью рабочим без ключей и сети.

Модель по умолчанию — Claude Opus 4.8 (claude-opus-4-8), новейшая на момент
написания. Переопределяется переменной окружения FINANOMALY_MODEL.
"""

from __future__ import annotations

import json
import os

from .models import Anomaly

_DEFAULT_MODEL = os.environ.get("FINANOMALY_MODEL", "claude-opus-4-8")

_SYSTEM = (
    "Ты — аналитик финансового мониторинга. По данным об аномалии во временном "
    "ряде дай краткое (1-3 предложения) объяснение на русском: что произошло, "
    "насколько это подозрительно и какое действие предпринять. Без воды."
)


def _rule_based(anomaly: Anomaly) -> str:
    p = anomaly.point
    dir_ru = {"up": "резкий рост", "down": "резкое падение", "spike": "всплеск"}
    d = dir_ru.get(anomaly.direction, anomaly.direction)
    action = {
        "high": "Требует немедленной проверки оператором.",
        "medium": "Рекомендуется ручная проверка.",
        "low": "Достаточно зафиксировать для аудита.",
    }[anomaly.severity]
    return (
        f"{d.capitalize()} метрики «{p.label}» до {p.value:,.2f} "
        f"({p.timestamp:%Y-%m-%d %H:%M} UTC). "
        f"Уверенность детекции {anomaly.score:.0%}, уровень риска: {anomaly.severity}. "
        f"{action}"
    )


class AiExplainer:
    def __init__(self, model: str = _DEFAULT_MODEL, enabled: bool = True) -> None:
        self.model = model
        self._client = None
        self.use_llm = False
        if not enabled:
            return
        api_key = os.environ.get("ANTHROPIC_API_KEY")
        if not api_key:
            return
        try:
            import anthropic

            self._client = anthropic.Anthropic(api_key=api_key)
            self.use_llm = True
        except Exception:
            self._client = None
            self.use_llm = False

    def explain(self, anomaly: Anomaly) -> str:
        if not self.use_llm or self._client is None:
            return _rule_based(anomaly)
        try:
            payload = {
                "label": anomaly.point.label,
                "timestamp": anomaly.point.timestamp.isoformat(),
                "value": anomaly.point.value,
                "direction": anomaly.direction,
                "score": round(anomaly.score, 3),
                "severity": anomaly.severity,
                "detector_reason": anomaly.reason,
            }
            msg = self._client.messages.create(
                model=self.model,
                max_tokens=300,
                system=_SYSTEM,
                messages=[{"role": "user", "content": json.dumps(payload, ensure_ascii=False)}],
            )
            text = "".join(block.text for block in msg.content if block.type == "text")
            return text.strip() or _rule_based(anomaly)
        except Exception:
            # Любой сбой ИИ не должен ронять пайплайн — откатываемся к правилам
            return _rule_based(anomaly)

    def annotate(self, anomalies: list[Anomaly]) -> list[Anomaly]:
        for a in anomalies:
            a.ai_explanation = self.explain(a)
        return anomalies
