"""Вычислительный движок детекции аномалий."""

from .core import AnomalyEngine, EngineResult, default_detectors
from .detectors import (
    Cusum,
    Detector,
    EwmaControlChart,
    Hampel,
    IsolationForestDetector,
    RobustMAD,
    SpectralResidual,
)
from .streaming import StreamingDetector

__all__ = [
    "AnomalyEngine",
    "EngineResult",
    "default_detectors",
    "Detector",
    "SeasonalResidualMAD",
    "SpectralResidual",
    "EwmaControlChart",
    "Cusum",
    "Hampel",
    "IsolationForestDetector",
    "StreamingDetector",
]
