"""Слияние оценок детекторов в единую вероятность аномалии.

Используется взвешенный noisy-OR: итоговая оценка
    P = 1 - Π_i (1 - w_i · s_i)
где s_i — оценка детектора, w_i — его нормированный вес надёжности.
Такая схема вознаграждает согласие независимых методов (несколько слабых
сигналов складываются в уверенный), оставаясь в диапазоне [0, 1].
"""

from __future__ import annotations


def normalize_weights(weights: list[float]) -> list[float]:
    m = max(weights) if weights else 1.0
    m = m or 1.0
    return [w / m for w in weights]


def fuse_point(scores: list[float], weights: list[float]) -> float:
    """Слить оценки детекторов для одной точки в [0, 1]."""
    prod = 1.0
    for s, w in zip(scores, weights):
        prod *= 1.0 - max(0.0, min(1.0, w * s))
    return 1.0 - prod


def fuse_series(
    score_matrix: list[list[float]], weights: list[float]
) -> list[float]:
    """score_matrix[d][i] — оценка детектора d в точке i. Вернуть слитый ряд."""
    if not score_matrix:
        return []
    norm_w = normalize_weights(weights)
    n = len(score_matrix[0])
    fused = []
    for i in range(n):
        col = [score_matrix[d][i] for d in range(len(score_matrix))]
        fused.append(fuse_point(col, norm_w))
    return fused
