"""Предобработка временного ряда: робастная статистика, сглаживание,
сезонная декомпозиция. Чистый Python, без сторонних зависимостей."""

from __future__ import annotations

import math


def median(xs: list[float]) -> float:
    if not xs:
        return 0.0
    s = sorted(xs)
    n = len(s)
    mid = n // 2
    return s[mid] if n % 2 else (s[mid - 1] + s[mid]) / 2


def mad(xs: list[float], center: float | None = None) -> float:
    """Median Absolute Deviation, масштабированный к сигме нормального закона."""
    if not xs:
        return 0.0
    c = median(xs) if center is None else center
    return 1.4826 * median([abs(x - c) for x in xs])


def quantile(xs: list[float], q: float) -> float:
    if not xs:
        return 0.0
    s = sorted(xs)
    pos = q * (len(s) - 1)
    lo = math.floor(pos)
    hi = math.ceil(pos)
    if lo == hi:
        return s[int(pos)]
    return s[lo] * (hi - pos) + s[hi] * (pos - lo)


def moving_average(xs: list[float], window: int) -> list[float]:
    """Центрированное скользящее среднее; края — усечённое окно."""
    n = len(xs)
    if window <= 1 or n == 0:
        return list(xs)
    half = window // 2
    out: list[float] = []
    for i in range(n):
        lo = max(0, i - half)
        hi = min(n, i + half + 1)
        seg = xs[lo:hi]
        out.append(sum(seg) / len(seg))
    return out


def rolling_median(xs: list[float], window: int) -> list[float]:
    n = len(xs)
    half = window // 2
    return [median(xs[max(0, i - half):min(n, i + half + 1)]) for i in range(n)]


def detect_period(values: list[float], max_period: int | None = None) -> int:
    """Оценить доминирующий период по автокорреляции (0 = периода нет)."""
    n = len(values)
    if n < 8:
        return 0
    mu = sum(values) / n
    var = sum((v - mu) ** 2 for v in values) or 1e-9
    max_p = min(max_period or n // 2, n // 2)
    best_lag, best_corr = 0, 0.0
    for lag in range(2, max_p + 1):
        cov = sum((values[i] - mu) * (values[i - lag] - mu) for i in range(lag, n))
        corr = cov / var / (n - lag) * n
        if corr > best_corr:
            best_corr, best_lag = corr, lag
    return best_lag if best_corr > 0.3 else 0


def seasonal_decompose(values: list[float], period: int) -> dict[str, list[float]]:
    """Классическая аддитивная декомпозиция: тренд + сезонность + остаток.

    Возвращает {'trend', 'seasonal', 'residual'}. Если period<=1 — тренд
    оценивается робастной скользящей медианой, сезонность нулевая.
    """
    n = len(values)
    if period <= 1:
        win = max(3, n // 10 | 1)
        trend = rolling_median(values, win)
        seasonal = [0.0] * n
        residual = [values[i] - trend[i] for i in range(n)]
        return {"trend": trend, "seasonal": seasonal, "residual": residual}

    trend = moving_average(values, period if period % 2 else period + 1)
    detrended = [values[i] - trend[i] for i in range(n)]

    # Сезонный профиль: медиана детрендированного по фазе
    by_phase: dict[int, list[float]] = {}
    for i, d in enumerate(detrended):
        by_phase.setdefault(i % period, []).append(d)
    profile = {ph: median(vals) for ph, vals in by_phase.items()}
    mean_profile = sum(profile.values()) / len(profile)
    profile = {ph: v - mean_profile for ph, v in profile.items()}  # центрируем

    seasonal = [profile[i % period] for i in range(n)]
    residual = [values[i] - trend[i] - seasonal[i] for i in range(n)]
    return {"trend": trend, "seasonal": seasonal, "residual": residual}


def squash(x: float, scale: float) -> float:
    """Перевести неограниченное превышение порога в score 0..1 (мягкое насыщение)."""
    if x <= 0 or scale <= 0:
        return 0.0
    return 1.0 - math.exp(-x / scale)
