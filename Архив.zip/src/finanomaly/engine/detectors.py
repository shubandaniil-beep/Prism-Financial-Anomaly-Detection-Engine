"""Детекторы движка. Каждый принимает числовой ряд и возвращает массив оценок
аномальности в [0, 1], выровненный по входу. Дискретные решения принимает
слой слияния (fusion), а не отдельный детектор.
"""

from __future__ import annotations

import cmath
import math
from abc import ABC, abstractmethod

from . import preprocessing as pp
from .fft import amplitude_phase, ifft


class Detector(ABC):
    name: str = "base"
    weight: float = 1.0  # надёжность детектора при слиянии

    @abstractmethod
    def score(self, values: list[float], period: int = 0) -> list[float]:
        raise NotImplementedError


class RobustMAD(Detector):
    """Глобальный робастный z-score (медиана + MAD) на стационарном остатке.

    Тренд и сезонность снимает движок до вызова детектора, поэтому здесь
    остаётся устойчивая к выбросам оценка глобального отклонения."""

    name = "robust_mad"
    weight = 1.3

    def __init__(self, threshold: float = 3.5) -> None:
        self.threshold = threshold

    def score(self, values: list[float], period: int = 0) -> list[float]:
        n = len(values)
        if n < 4:
            return [0.0] * n
        center = pp.median(values)
        scale = pp.mad(values, center) or 1e-9
        out = []
        for v in values:
            z = abs(v - center) / scale
            out.append(pp.squash(z - self.threshold, scale=4.0))
        return out


class SpectralResidual(Detector):
    """Метод спектрального остатка (Microsoft SR): аномалия = всплеск
    «заметности» (saliency) после подавления регулярных частот сигнала.
    Хорошо ловит резкие точечные выбросы и пробои."""

    name = "spectral_residual"
    weight = 1.1

    def __init__(self, avg_window: int = 3, score_window: int = 21, threshold: float = 3.0) -> None:
        self.avg_window = avg_window
        self.score_window = score_window
        self.threshold = threshold

    def score(self, values: list[float], period: int = 0) -> list[float]:
        n = len(values)
        if n < 8:
            return [0.0] * n
        amp, phase, _m = amplitude_phase(values)
        eps = 1e-8
        log_amp = [math.log(a + eps) for a in amp]
        avg_log = pp.moving_average(log_amp, self.avg_window)
        spectral_residual = [log_amp[i] - avg_log[i] for i in range(len(amp))]
        # Восстанавливаем сигнал заметности: амплитуда exp(R), исходная фаза
        recon = [cmath.rect(math.exp(spectral_residual[i]), phase[i]) for i in range(len(amp))]
        saliency_full = ifft(recon)
        saliency = [abs(z) ** 2 for z in saliency_full[:n]]

        local_mean = pp.moving_average(saliency, self.score_window)
        out = []
        for i in range(n):
            base = local_mean[i] or 1e-9
            rel = (saliency[i] - base) / base
            out.append(pp.squash(rel - self.threshold, scale=4.0))
        return out


class EwmaControlChart(Detector):
    """Контрольная карта EWMA: пробой адаптивного коридора ±kσ вокруг
    экспоненциально сглаженного уровня. Реагирует на смещения уровня."""

    name = "ewma"
    weight = 1.0

    def __init__(self, alpha: float = 0.25, threshold: float = 3.0) -> None:
        self.alpha = alpha
        self.threshold = threshold

    def score(self, values: list[float], period: int = 0) -> list[float]:
        n = len(values)
        if n < 5:
            return [0.0] * n
        out = [0.0]
        ewma = values[0]
        ewmvar = 0.0
        for v in values[1:]:
            std = math.sqrt(ewmvar) or 1e-9
            dev = abs(v - ewma) / std
            out.append(pp.squash(dev - self.threshold, scale=4.0))
            diff = v - ewma
            ewma += self.alpha * diff
            ewmvar = (1 - self.alpha) * (ewmvar + self.alpha * diff * diff)
        return out


class Cusum(Detector):
    """Двусторонний CUSUM: накопительная сумма отклонений выявляет устойчивые
    сдвиги среднего (постепенный увод, а не одиночный выброс)."""

    name = "cusum"
    weight = 0.9

    def __init__(self, k: float = 0.5, threshold: float = 5.0) -> None:
        self.k = k                # допуск в сигмах
        self.threshold = threshold

    def score(self, values: list[float], period: int = 0) -> list[float]:
        n = len(values)
        if n < 5:
            return [0.0] * n
        mu = pp.median(values)
        sigma = pp.mad(values, mu) or 1e-9
        z = [(v - mu) / sigma for v in values]
        s_hi = s_lo = 0.0
        out = []
        for zi in z:
            s_hi = max(0.0, s_hi + zi - self.k)
            s_lo = min(0.0, s_lo + zi + self.k)
            excess = max(s_hi, -s_lo) - self.threshold
            out.append(pp.squash(excess, scale=4.0))
        return out


class Hampel(Detector):
    """Фильтр Хампеля: локальная робастная z-оценка в скользящем окне.
    Чувствителен к точечным выбросам относительно ближайших соседей."""

    name = "hampel"
    weight = 1.0

    def __init__(self, window: int = 11, threshold: float = 3.0) -> None:
        self.window = window | 1   # нечётное
        self.threshold = threshold

    def score(self, values: list[float], period: int = 0) -> list[float]:
        n = len(values)
        if n < self.window:
            return [0.0] * n
        half = self.window // 2
        out = []
        for i in range(n):
            seg = values[max(0, i - half):min(n, i + half + 1)]
            med = pp.median(seg)
            scale = pp.mad(seg, med) or 1e-9
            z = abs(values[i] - med) / scale
            out.append(pp.squash(z - self.threshold, scale=4.0))
        return out


class IsolationForestDetector(Detector):
    """ML-детектор Isolation Forest (scikit-learn) на многомерных признаках.
    Опционален: при отсутствии sklearn возвращает нули и не мешает движку."""

    name = "isolation_forest"
    weight = 1.2

    def __init__(self, contamination: float = 0.03, random_state: int = 42) -> None:
        self.contamination = contamination
        self.random_state = random_state
        try:
            import numpy  # noqa: F401
            from sklearn.ensemble import IsolationForest  # noqa: F401

            self.available = True
        except Exception:
            self.available = False

    def score(self, values: list[float], period: int = 0) -> list[float]:
        n = len(values)
        if not self.available or n < 20:
            return [0.0] * n
        import numpy as np
        from sklearn.ensemble import IsolationForest

        roll = pp.moving_average(values, 7)
        prev = values[0]
        feats = []
        for i, v in enumerate(values):
            feats.append([v, v - prev, v - roll[i], float(i % max(period, 1))])
            prev = v
        X = np.asarray(feats, dtype=float)
        model = IsolationForest(
            contamination=self.contamination,
            random_state=self.random_state,
            n_estimators=200,
        )
        model.fit(X)
        raw = model.score_samples(X)        # больше = нормальнее
        lo, hi = float(raw.min()), float(raw.max())
        span = (hi - lo) or 1e-9
        return [float((hi - r) / span) for r in raw]
