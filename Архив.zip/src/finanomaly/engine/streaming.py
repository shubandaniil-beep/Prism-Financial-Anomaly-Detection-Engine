"""Онлайн-детектор для потоковых данных (реальное время).

Поддерживает скользящее окно и инкрементальные EWMA-статистики, поэтому
оценивает каждое новое значение за O(window) без пересчёта всей истории.
Подходит для мониторинга котировок/транзакций «на лету».
"""

from __future__ import annotations

from collections import deque

from ..models import Anomaly, DataPoint
from . import preprocessing as pp


class StreamingDetector:
    def __init__(
        self,
        window: int = 64,
        alpha: float = 0.2,
        ewma_threshold: float = 3.0,
        hampel_threshold: float = 3.0,
        warmup: int = 16,
        fuse_threshold: float = 0.5,
    ) -> None:
        self.window = window
        self.alpha = alpha
        self.ewma_threshold = ewma_threshold
        self.hampel_threshold = hampel_threshold
        self.warmup = warmup
        self.fuse_threshold = fuse_threshold

        self._buf: deque[float] = deque(maxlen=window)
        self._ewma: float | None = None
        self._ewmvar = 0.0
        self._count = 0

    def update(self, value: float) -> float:
        """Подать значение, вернуть оценку аномальности [0, 1]."""
        self._count += 1
        score = 0.0

        if self._ewma is not None:
            std = self._ewmvar ** 0.5 or 1e-9
            ewma_dev = abs(value - self._ewma) / std
            s_ewma = pp.squash(ewma_dev - self.ewma_threshold, scale=4.0)

            seg = list(self._buf)
            med = pp.median(seg)
            scale = pp.mad(seg, med) or 1e-9
            hampel_dev = abs(value - med) / scale
            s_hampel = pp.squash(hampel_dev - self.hampel_threshold, scale=4.0)

            if self._count > self.warmup:
                score = 1.0 - (1.0 - s_ewma) * (1.0 - s_hampel)  # noisy-OR

        # Обновляем состояние ПОСЛЕ оценки (точку оцениваем по прошлому)
        if self._ewma is None:
            self._ewma = value
        else:
            diff = value - self._ewma
            self._ewma += self.alpha * diff
            self._ewmvar = (1 - self.alpha) * (self._ewmvar + self.alpha * diff * diff)
        self._buf.append(value)
        return score

    def push(self, point: DataPoint) -> Anomaly | None:
        """Подать DataPoint, вернуть Anomaly если оценка превысила порог."""
        score = self.update(point.value)
        if score < self.fuse_threshold:
            return None
        direction = "up" if (self._ewma is None or point.value >= self._ewma) else "down"
        return Anomaly(
            point=point,
            score=score,
            direction=direction,
            contributions={"stream_ewma": score},
            reason="онлайн-детекция: пробой EWMA/Hampel-коридора в реальном времени",
        )
