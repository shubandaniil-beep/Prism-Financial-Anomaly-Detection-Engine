"""AnomalyEngine — оркестратор вычислительного движка.

Конвейер:
    1. извлечение значений из ряда DataPoint;
    2. (опц.) лог-преобразование для рядов с мультипликативным шумом;
    3. оценка доминирующего периода (для сезонной декомпозиции);
    4. прогон всех детекторов → матрица оценок;
    5. взвешенное слияние (noisy-OR) → итоговая оценка по каждой точке;
    6. порог + определение направления и причины → список Anomaly.

Движок батчевый; для онлайн-режима см. streaming.StreamingDetector.
"""

from __future__ import annotations

import math
from dataclasses import dataclass, field

from ..models import Anomaly, DataPoint
from . import preprocessing as pp
from .detectors import (
    Cusum,
    Detector,
    EwmaControlChart,
    Hampel,
    IsolationForestDetector,
    RobustMAD,
    SpectralResidual,
)
from .fusion import fuse_series, normalize_weights


def default_detectors() -> list[Detector]:
    return [
        RobustMAD(),
        SpectralResidual(),
        EwmaControlChart(),
        Cusum(),
        Hampel(),
        IsolationForestDetector(),
    ]


@dataclass
class EngineResult:
    series: list[DataPoint]
    scores: list[float]                       # слитая оценка по каждой точке
    contributions: list[dict[str, float]]     # вклад детекторов по каждой точке
    anomalies: list[Anomaly]
    period: int = 0
    detectors: list[str] = field(default_factory=list)

    @property
    def anomaly_rate(self) -> float:
        return len(self.anomalies) / len(self.series) if self.series else 0.0

    def summary(self) -> dict:
        by_sev = {"high": 0, "medium": 0, "low": 0}
        for a in self.anomalies:
            by_sev[a.severity] += 1
        return {
            "points": len(self.series),
            "anomalies": len(self.anomalies),
            "anomaly_rate": round(self.anomaly_rate, 4),
            "by_severity": by_sev,
            "period": self.period,
            "detectors": self.detectors,
        }


class AnomalyEngine:
    def __init__(
        self,
        detectors: list[Detector] | None = None,
        threshold: float = 0.5,
        log_transform: str = "auto",     # "auto" | "on" | "off"
        period: int | None = None,        # None = оценить автоматически
    ) -> None:
        self.detectors = detectors if detectors is not None else default_detectors()
        self.threshold = threshold
        self.log_transform = log_transform
        self.period = period

    # --- внутреннее ---

    def _maybe_log(self, values: list[float]) -> tuple[list[float], bool]:
        if self.log_transform == "off":
            return values, False
        positive = all(v > 0 for v in values)
        if self.log_transform == "on" and positive:
            return [math.log(v) for v in values], True
        if self.log_transform == "auto" and positive and values:
            # Лог-преобразование, если разброс мультипликативный (большой CV)
            mu = sum(values) / len(values)
            sd = pp.mad(values)
            if mu > 0 and sd / mu > 0.5:
                return [math.log(v) for v in values], True
        return values, False

    def _direction(self, values: list[float], i: int, period: int) -> str:
        decomp = pp.seasonal_decompose(values, period)
        baseline = decomp["trend"][i] + decomp["seasonal"][i]
        return "up" if values[i] >= baseline else "down"

    # --- публичное ---

    def run(self, series: list[DataPoint]) -> EngineResult:
        raw_values = [p.value for p in series]
        n = len(raw_values)
        names = [d.name for d in self.detectors]
        if n == 0:
            return EngineResult([], [], [], [], 0, names)

        values, _logged = self._maybe_log(raw_values)
        period = self.period if self.period is not None else pp.detect_period(values)

        # Снимаем тренд и сезонность один раз: детекторы работают на стационарном
        # остатке, иначе они принимают регулярную динамику ряда за аномалии.
        residual = pp.seasonal_decompose(values, period)["residual"]

        matrix = [d.score(residual, period) for d in self.detectors]
        weights = [d.weight for d in self.detectors]
        fused = fuse_series(matrix, weights)

        norm_w = normalize_weights(weights)
        contributions: list[dict[str, float]] = []
        for i in range(n):
            contrib = {
                names[d]: round(norm_w[d] * matrix[d][i], 4)
                for d in range(len(self.detectors))
                if matrix[d][i] > 0.01
            }
            contributions.append(contrib)

        anomalies: list[Anomaly] = []
        for i, sc in enumerate(fused):
            if sc < self.threshold:
                continue
            contrib = dict(sorted(contributions[i].items(), key=lambda kv: kv[1], reverse=True))
            top = next(iter(contrib), "engine")
            anomalies.append(
                Anomaly(
                    point=series[i],
                    score=sc,
                    direction=self._direction(raw_values, i, period),
                    contributions=contrib,
                    reason=(
                        f"согласие детекторов ({len(contrib)}): "
                        f"ведущий — {top}; период ряда ≈ {period or 'нет'}"
                    ),
                )
            )

        anomalies.sort(key=lambda a: a.score, reverse=True)
        return EngineResult(
            series=series,
            scores=fused,
            contributions=contributions,
            anomalies=anomalies,
            period=period,
            detectors=names,
        )
