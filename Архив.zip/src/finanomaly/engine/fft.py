"""Быстрое преобразование Фурье на чистом Python (итеративный Cooley–Tukey).

Используется детектором спектрального остатка. Реализовано без numpy, чтобы
движок оставался самодостаточным; при наличии numpy движок может работать
быстрее, но эта реализация — корректный fallback для рядов до ~4096 точек.
"""

from __future__ import annotations

import cmath
from math import ceil, log2


def next_pow2(n: int) -> int:
    return 1 if n <= 1 else 2 ** ceil(log2(n))


def fft(a: list[complex], invert: bool = False) -> list[complex]:
    """In-place итеративный радикс-2 FFT. Длина a должна быть степенью двойки."""
    a = list(a)
    n = len(a)
    if n & (n - 1):
        raise ValueError("длина должна быть степенью двойки")

    # Перестановка по обратным битам
    j = 0
    for i in range(1, n):
        bit = n >> 1
        while j & bit:
            j ^= bit
            bit >>= 1
        j ^= bit
        if i < j:
            a[i], a[j] = a[j], a[i]

    length = 2
    while length <= n:
        ang = (2j * cmath.pi / length) * (1 if invert else -1)
        wlen = cmath.exp(ang)
        half = length >> 1
        for i in range(0, n, length):
            w = 1 + 0j
            for k in range(half):
                u = a[i + k]
                v = a[i + k + half] * w
                a[i + k] = u + v
                a[i + k + half] = u - v
                w *= wlen
        length <<= 1

    if invert:
        a = [x / n for x in a]
    return a


def ifft(a: list[complex]) -> list[complex]:
    return fft(a, invert=True)


def amplitude_phase(values: list[float]) -> tuple[list[float], list[float], int]:
    """Вернуть (амплитуды, фазы, длина_с_паддингом) для вещественного сигнала."""
    n = len(values)
    m = next_pow2(n)
    padded = [complex(v, 0.0) for v in values] + [0j] * (m - n)
    spec = fft(padded)
    amp = [abs(z) for z in spec]
    phase = [cmath.phase(z) for z in spec]
    return amp, phase, m
